/*
 * Raw video codec
 * Copyright (c) 2001 Gerard Lantau.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <netinet/in.h>
#include "avcodec.h"

static int decode_init(AVEncodeContext *s)
{
    if (s->pix_fmt != PIX_FMT_YUV420P)
        return -1;

    return 0;
}

static int decode_frame(AVEncodeContext *s, UINT8 *buf, int buf_size, 
                        void *data)
{
    memcpy(buf, data, buf_size);
    return buf_size;
}

/* XXX: only 420P handled */
static int encode_init(AVEncodeContext *s)
{
    if (s->pix_fmt != PIX_FMT_YUV420P)
        return -1;
    return 0;
}

static int encode_frame(AVEncodeContext *avctx,
                        unsigned char *frame, int buf_size, void *data)
{
    memcpy(frame, data, buf_size);
    return buf_size;
}

AVEncoder rawvideo_encoder = {
    "rawvideo",
    CODEC_TYPE_VIDEO,
    CODEC_ID_RAWVIDEO,
    0,
    encode_init,
    encode_frame,
    NULL,
};

AVEncoder rawvideo_decoder = {
    "rawvideo",
    CODEC_TYPE_VIDEO,
    CODEC_ID_RAWVIDEO,
    0,
    decode_init,
    decode_frame,
    NULL,
    1, /* is_decoder */
};
