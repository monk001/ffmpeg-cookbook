/*
 * Flash Compatible Streaming Format
 * Copyright (c) 2000 Gerard Lantau.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <stdlib.h>
#include <stdio.h>
#include <netinet/in.h>
#include <string.h>
#include "avformat.h"

#include <assert.h>

/* should have a generic way to indicate probable size */
#define DUMMY_FILE_SIZE   (100 * 1024 * 1024)
#define DUMMY_DURATION    600 /* in seconds */

#define TAG_END           0
#define TAG_SHOWFRAME     1
#define TAG_DEFINESHAPE   2
#define TAG_FREECHARACTER 3
#define TAG_PLACEOBJECT   4
#define TAG_REMOVEOBJECT  5
#define TAG_STREAMHEAD    18
#define TAG_STREAMBLOCK   19
#define TAG_JPEG2         21

#define TAG_LONG         0x100

/* flags for shape definition */
#define FLAG_MOVETO      0x01
#define FLAG_SETFILL0    0x02
#define FLAG_SETFILL1    0x04

/* character id used */
#define BITMAP_ID 0
#define SHAPE_ID  1

typedef struct {
    long long duration_pos;
    long long tag_pos;
    int tag;
} SWFContext;

static void put_swf_tag(AVFormatContext *s, int tag)
{
    SWFContext *swf = s->priv_data;
    ByteIOContext *pb = &s->pb;

    swf->tag_pos = url_ftell(pb);
    swf->tag = tag;
    /* reserve some room for the tag */
    if (tag & TAG_LONG) {
        put_le16(pb, 0);
        put_le32(pb, 0);
    } else {
        put_le16(pb, 0);
    }
}

static void put_swf_end_tag(AVFormatContext *s)
{
    SWFContext *swf = s->priv_data;
    ByteIOContext *pb = &s->pb;
    long long pos;
    int tag_len, tag;

    pos = url_ftell(pb);
    tag_len = pos - swf->tag_pos - 2;
    tag = swf->tag;
    url_fseek(pb, swf->tag_pos, SEEK_SET);
    if (tag & TAG_LONG) {
        tag &= ~TAG_LONG;
        put_le16(pb, (tag << 6) | 0x3f);
        put_le32(pb, tag_len - 4);
    } else {
        assert(tag_len < 0x3f);
        put_le16(pb, (tag << 6) | tag_len);
    }
    url_fseek(pb, pos, SEEK_SET);
}

static inline void max_nbits(int *nbits_ptr, int val)
{
    int n;

    if (val == 0)
        return;
    val = abs(val);
    n = 1;
    while (val != 0) {
        n++;
        val >>= 1;
    }
    if (n > *nbits_ptr)
        *nbits_ptr = n;
}

static void put_swf_rect(ByteIOContext *pb, 
                         int xmin, int xmax, int ymin, int ymax)
{
    PutBitContext p;
    UINT8 buf[256];
    int nbits, mask;

    init_put_bits(&p, buf, sizeof(buf), NULL, NULL);
    
    nbits = 0;
    max_nbits(&nbits, xmin);
    max_nbits(&nbits, xmax);
    max_nbits(&nbits, ymin);
    max_nbits(&nbits, ymax);
    mask = (1 << nbits) - 1;

    /* rectangle info */
    put_bits(&p, 5, nbits);
    put_bits(&p, nbits, xmin & mask);
    put_bits(&p, nbits, xmax & mask);
    put_bits(&p, nbits, ymin & mask);
    put_bits(&p, nbits, ymax & mask);
    
    flush_put_bits(&p);
    put_buffer(pb, buf, p.buf_ptr - p.buf);
}

static void put_swf_line_edge(PutBitContext *pb, int dx, int dy)
{
    int nbits, mask;

    put_bits(pb, 1, 1); /* edge */
    put_bits(pb, 1, 1); /* line select */
    nbits = 2;
    max_nbits(&nbits, dx);
    max_nbits(&nbits, dy);

    mask = (1 << nbits) - 1;
    put_bits(pb, 4, nbits - 2); /* 16 bits precision */
    if (dx == 0) {
      put_bits(pb, 1, 0); 
      put_bits(pb, 1, 1); 
      put_bits(pb, nbits, dy & mask);
    } else if (dy == 0) {
      put_bits(pb, 1, 0); 
      put_bits(pb, 1, 0); 
      put_bits(pb, nbits, dx & mask);
    } else {
      put_bits(pb, 1, 1); 
      put_bits(pb, nbits, dx & mask);
      put_bits(pb, nbits, dy & mask);
    }
}

#define FRAC_BITS 16

/* put matrix (not size optimized */
static void put_swf_matrix(ByteIOContext *pb,
                           int a, int b, int c, int d, int tx, int ty)
{
    PutBitContext p;
    UINT8 buf[256];

    init_put_bits(&p, buf, sizeof(buf), NULL, NULL);
    
    put_bits(&p, 1, 1); /* a, d present */
    put_bits(&p, 5, 20); /* nb bits */
    put_bits(&p, 20, a);
    put_bits(&p, 20, d);
    
    put_bits(&p, 1, 1); /* b, c present */
    put_bits(&p, 5, 20); /* nb bits */
    put_bits(&p, 20, c);
    put_bits(&p, 20, b);

    put_bits(&p, 5, 20); /* nb bits */
    put_bits(&p, 20, tx);
    put_bits(&p, 20, ty);

    flush_put_bits(&p);
    put_buffer(pb, buf, p.buf_ptr - p.buf);
}

/* XXX: handle audio only */
static int swf_write_header(AVFormatContext *s)
{
    SWFContext *swf;
    ByteIOContext *pb = &s->pb;
    AVCodecContext *enc, *audio_enc, *video_enc;
    PutBitContext p;
    UINT8 buf1[256];
    int i;

    swf = malloc(sizeof(SWFContext));
    if (!swf)
        return -1;
    s->priv_data = swf;

    video_enc = NULL;
    audio_enc = NULL;
    for(i=0;i<s->nb_streams;i++) {
        enc = &s->streams[i]->codec;
        if (enc->codec->type == CODEC_TYPE_AUDIO)
            audio_enc = enc;
        else
            video_enc = enc;
    }

    put_tag(pb, "FWS");
    put_byte(pb, 3); /* version (should use 4 for mpeg audio support) */
    put_le32(pb, DUMMY_FILE_SIZE); /* dummy size 
                                      (will be patched if not streamed) */ 

    put_swf_rect(pb, 0, video_enc->width, 0, video_enc->height);
    put_le16(pb, video_enc->rate << 8); /* frame rate */
    swf->duration_pos = url_ftell(pb);
    put_le16(pb, DUMMY_DURATION * video_enc->rate); /* frame count */
    
    /* define a shape with the jpeg inside */

    put_swf_tag(s, TAG_DEFINESHAPE);

    put_le16(pb, SHAPE_ID); /* ID of shape */
    /* bounding rectangle */
    put_swf_rect(pb, 0, video_enc->width, 0, video_enc->height);
    /* style info */
    put_byte(pb, 1); /* one fill style */
    put_byte(pb, 0x41); /* clipped bitmap fill */
    put_le16(pb, BITMAP_ID); /* bitmap ID */
    /* position of the bitmap */
    put_swf_matrix(pb, (int)(1.0 * (1 << FRAC_BITS)), 0, 
                   0, (int)(1.0 * (1 << FRAC_BITS)), 0, 0);
    put_byte(pb, 0); /* no line style */
    
    /* shape drawing */
    init_put_bits(&p, buf1, sizeof(buf1), NULL, NULL);
    put_bits(&p, 4, 1); /* one fill bit */
    put_bits(&p, 4, 0); /* zero line bit */
    
    put_bits(&p, 1, 0); /* not an edge */
    put_bits(&p, 5, FLAG_MOVETO | FLAG_SETFILL0);
    put_bits(&p, 5, 1); /* nbits */
    put_bits(&p, 1, 0); /* X */
    put_bits(&p, 1, 0); /* Y */
    put_bits(&p, 1, 1); /* set fill style 1 */
    
    /* draw the rectangle ! */
    put_swf_line_edge(&p, video_enc->width, 0);
    put_swf_line_edge(&p, 0, video_enc->height);
    put_swf_line_edge(&p, -video_enc->width, 0);
    put_swf_line_edge(&p, 0, -video_enc->height);
    
    /* end of shape */
    put_bits(&p, 1, 0); /* not an edge */
    put_bits(&p, 5, 0);

    flush_put_bits(&p);
    put_buffer(pb, buf1, p.buf_ptr - p.buf);

    put_swf_end_tag(s);

    
    if (audio_enc) {
        int v;

        /* start sound */

        v = 0;
        switch(audio_enc->rate) {
        case 11025:
            v |= 1 << 2;
            break;
        case 22050:
            v |= 2 << 2;
            break;
        case 44100:
            v |= 3 << 2;
            break;
        default:
            /* not supported */
            free(swf);
            return -1;
        }
        if (audio_enc->channels == 2)
            v |= 1;
        v |= 0x20; /* mp3 compressed */
        v |= 0x02; /* 16 bits */
        
        put_swf_tag(s, TAG_STREAMHEAD);
        put_byte(&s->pb, 0);
        put_byte(&s->pb, v);
        put_le16(&s->pb, audio_enc->rate / video_enc->rate); /* avg samples per frame */
        
        put_swf_end_tag(s);
    }

    put_flush_packet(&s->pb);
    return 0;
}

static int swf_write_video(AVFormatContext *s, 
                           AVCodecContext *enc, UINT8 *buf, int size)
{
    ByteIOContext *pb = &s->pb;
    static int tag_id = 0;

    if (enc->frame_number > 1) {
        /* remove the shape */
        put_swf_tag(s, TAG_REMOVEOBJECT);
        put_le16(pb, SHAPE_ID); /* shape ID */
        put_le16(pb, 1); /* depth */
        put_swf_end_tag(s);
        
        /* free the bitmap */
        put_swf_tag(s, TAG_FREECHARACTER);
        put_le16(pb, BITMAP_ID);
        put_swf_end_tag(s);
    }

    put_swf_tag(s, TAG_JPEG2 | TAG_LONG);

    put_le16(pb, tag_id); /* ID of the image */

    /* a dummy jpeg header seems to be required */
    put_byte(pb, 0xff); 
    put_byte(pb, 0xd8);
    put_byte(pb, 0xff);
    put_byte(pb, 0xd9);
    /* write the jpeg image */
    put_buffer(pb, buf, size);

    put_swf_end_tag(s);

    /* draw the shape */

    put_swf_tag(s, TAG_PLACEOBJECT);
    put_le16(pb, SHAPE_ID); /* shape ID */
    put_le16(pb, 1); /* depth */
    put_swf_matrix(pb, 1 << FRAC_BITS, 0, 0, 1 << FRAC_BITS, 0, 0);
    put_swf_end_tag(s);
    
    /* output the frame */
    put_swf_tag(s, TAG_SHOWFRAME);
    put_swf_end_tag(s);
    
    put_flush_packet(&s->pb);
    return 0;
}

static int swf_write_audio(AVFormatContext *s, UINT8 *buf, int size)
{
    ByteIOContext *pb = &s->pb;

    put_swf_tag(s, TAG_STREAMBLOCK | TAG_LONG);

    put_buffer(pb, buf, size);
    
    put_swf_end_tag(s);
    put_flush_packet(&s->pb);
    return 0;
}

static int swf_write_packet(AVFormatContext *s, int stream_index, 
                           UINT8 *buf, int size)
{
    AVCodecContext *codec = &s->streams[stream_index]->codec;
    if (codec->codec->type == 
        CODEC_TYPE_AUDIO)
        return swf_write_audio(s, buf, size);
    else
        return swf_write_video(s, codec, buf, size);
}

static int swf_write_trailer(AVFormatContext *s)
{
    SWFContext *swf = s->priv_data;
    ByteIOContext *pb = &s->pb;
    AVCodecContext *enc, *video_enc;
    int file_size, i;

    video_enc = NULL;
    for(i=0;i<s->nb_streams;i++) {
        enc = &s->streams[i]->codec;
        if (enc->codec->type == CODEC_TYPE_VIDEO)
            video_enc = enc;
    }

    put_swf_tag(s, TAG_END);
    put_swf_end_tag(s);
    
    put_flush_packet(&s->pb);

    /* patch file size and number of frames if not streamed */
    if (!url_is_streamed(&s->pb)) {
        file_size = url_ftell(pb);
        url_fseek(pb, 4, SEEK_SET);
        put_le32(pb, file_size);
        url_fseek(pb, swf->duration_pos, SEEK_SET);
        put_le16(pb, video_enc->frame_number);
    }
    free(swf);
    return 0;
}

AVFormat swf_format = {
    "swf",
    "Flash format",
    "application/x-shockwave-flash",
    "swf",
    CODEC_ID_MP2,
    CODEC_ID_MJPEG,
    swf_write_header,
    swf_write_packet,
    swf_write_trailer,
};
