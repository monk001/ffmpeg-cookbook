/*
 * Image protocol 
 * Copyright (c) 2000,2001 Gerard Lantau.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <math.h>

#include "avformat.h"

#define INFMT_YUV 1
#define INFMT_PGM 2

typedef struct {
    int width;
    int height;
    int img_number;
    int img_size;
    int img_fmt;
    char path[1024];
} VideoData;

static inline int pnm_space(int c)  
{
    return (c==' ' || c=='\n' || c=='\r' || c=='\t');
}

static void pnm_get(FILE *f, char *str, int buf_size) 
{
    char *s;
    int c;
    
    do  {
        c=fgetc(f);
        if (c=='#')  {
            do  {
                c=fgetc(f);
            } while (c!='\n');
            c=fgetc(f);
        }
    } while (pnm_space(c));
    
    s=str;
    do  {
        *s++=c;
        c=fgetc(f);
    } while (!pnm_space(c));
    *s=0;
}

static int pgm_read(VideoData *s, const char *filename, UINT8 *buf, int size)
{
    int width, height, i;
    FILE *f;
    char buf1[32];
    UINT8 *picture[3];

    width = s->width;
    height = s->height;
    f=fopen(filename, "r");
    if (!f) {
        return -EIO;
    }
    pnm_get(f, buf1, sizeof(buf1));
    if (strcmp(buf1, "P5")) {
        fclose(f);
        return -EIO;
    }
    pnm_get(f, buf1, sizeof(buf1));
    pnm_get(f, buf1, sizeof(buf1));
    pnm_get(f, buf1, sizeof(buf1));
    
    picture[0] = buf;
    picture[1] = buf + width * height;
    picture[2] = buf + width * height + (width * height / 4);
    
    fread(picture[0], 1, width * height, f);
    for(i=0;i<height/2;i++) {
        fread(picture[1] + i * width/2, 1, width/2, f);
        fread(picture[2] + i * width/2, 1, width/2, f);
    }
    fclose(f);
    return 0;
}

static int yuv_read(VideoData *s, const char *filename, UINT8 *buf, int size1)
{
    FILE *f;
    char fname[1024], *p;
    int size;

    size = s->width * s->height;
    
    strcpy(fname, filename);
    p = strrchr(fname, '.');
    if (!p || p[1] != 'Y')
        return -EIO;

    f=fopen(fname, "r");
    if (!f) {
        return -EIO;
    }
    
    fread(buf, 1, size, f);
    fclose(f);
    
    p[1] = 'U';
    f=fopen(fname, "r");
    if (!f) {
        return -EIO;
    }
    fread(buf + size, 1, size / 4, f);
    fclose(f);
    
    p[1] = 'V';
    f=fopen(fname, "r");
    if (!f) {
        return -EIO;
    }
    fread(buf + size + (size / 4), 1, size / 4, f);
    fclose(f);
    return 0;
}

/* note: we support only one picture read at a time */
static int img_read(URLContext *h, UINT8 *buf, int size)
{
    VideoData *s = h->priv_data;
    char filename[1024];
    int ret;

    if (size < s->img_size)
        return -EIO;

    snprintf(filename, sizeof(filename), s->path, s->img_number);

    switch(s->img_fmt) {
    case INFMT_PGM:
        ret = pgm_read(s, filename, buf, size);
        break;
    case INFMT_YUV:
        ret = yuv_read(s, filename, buf, size);
        break;
    default:
        return -EIO;
    }
    if (ret < 0) {
        return 0; /* signal EOF */
    } else {
        s->img_number++;
        return s->img_size;
    }
}

static int img_get_format(URLContext *h, URLFormat *f)
{
    VideoData *s = h->priv_data;

    f->width = s->width;
    f->height = s->height;
    f->pix_fmt = PIX_FMT_YUV420P;
    strcpy(f->format_name, "rawvideo");
    return 0;
}

static int infer_size(int *width_ptr, int *height_ptr, int size)
{
    int w, h, wmin, hmin;
    float ratio, dmin, d;

    dmin = 10.0;
    wmin = -1;
    hmin = -1;
    for(w = 8; w <= 2048; w += 8) {
        h = size / w;
        if ((h * w) == size) {
            ratio = (float)w / (float)h;
            d = fabs(ratio - 4.0/3.0);
            if (d < dmin) {
                dmin = d;
                wmin = w;
                hmin = h;
            }
        }
    }
    if (dmin <= 1.0) {
        *width_ptr = w;
        *height_ptr = h;
        return 0;
    } else {
        return -1;
    }
}

/* URI syntax: PGM: 'img:/path/img%d.pgm[?start=n]' 
               YUV: 'img:/path/img%d.Y' 
 */
static int img_open(URLContext *h, const char *uri, int flags)
{
    VideoData *s;
    const char *p;
    int i;
    char buf[1024], *info;
    char buf1[32];
    FILE *f;

    s = malloc(sizeof(VideoData));
    if (!s)
        return -ENOMEM;

    h->priv_data = s;
    h->is_streamed = 1;
    
    p = uri;
    strstart(p, "img:", &p);
    
    /* XXX: bound check */
    strcpy(s->path, p);
    info = strchr(s->path, '?');

    s->img_number = 0;
    if (info) {
        if (find_info_tag(buf, sizeof(buf), "start", info))
            s->img_number = atoi(buf);
        *info = '\0';
    }

    /* find format */
    if (match_ext(s->path, "pgm"))
        s->img_fmt = INFMT_PGM;
    else if (match_ext(s->path, "Y"))
        s->img_fmt = INFMT_YUV;
    else
        goto fail;

    /* try to find the first image */
    f = NULL;
    for(i=0;i<5;i++) {
        snprintf(buf, sizeof(buf), s->path, s->img_number);
        f=fopen(buf, "r");
        if (f) {
            break;
        }
        s->img_number++;
    }
    if (i == 5)
        goto fail;
    
    /* find the image size */
    switch(s->img_fmt) {
    case INFMT_PGM:
        pnm_get(f, buf1, sizeof(buf1));
        pnm_get(f, buf1, sizeof(buf1));
        s->width = atoi(buf1);
        pnm_get(f, buf1, sizeof(buf1));
        s->height = (atoi(buf1) * 2) / 3;
        if (s->width <= 0 ||
            s->height <= 0) {
            fclose(f);
            goto fail;
        }
        break;
    case INFMT_YUV:
        /* infer size by using the file size. We choose the size
           closest to the 4/3 ratio */
        {
            int img_size;
            fseek(f, 0, SEEK_END);
            img_size = ftell(f);
            if (infer_size(&s->width, &s->height, img_size) < 0) {
                fclose(f);
                goto fail;
            }
        }
        break;
    }

    fclose(f);
    
    s->img_size = (s->width * s->height * 3) / 2;

    return 0;
 fail:
    free(s);
    return -EIO;
}

static int img_close(URLContext *h)
{
    VideoData *s = h->priv_data;
    free(s);
    return 0;
}

URLProtocol img_protocol = {
    "img",
    img_open,
    img_read,
    NULL,
    NULL, /* seek */
    img_close,
    img_get_format,
};
