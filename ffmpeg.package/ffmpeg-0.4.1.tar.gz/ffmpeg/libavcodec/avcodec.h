#include "common.h"

enum CodecID {
    CODEC_ID_NONE, 
    CODEC_ID_MPEG1VIDEO,
    CODEC_ID_H263,
    CODEC_ID_RV10,
    CODEC_ID_MP2,
    CODEC_ID_AC3,
    CODEC_ID_MJPEG,
    CODEC_ID_OPENDIVX,
    CODEC_ID_PCM,
    CODEC_ID_RAWVIDEO,
    CODEC_ID_MSMPEG4,
};

enum CodecType {
    CODEC_TYPE_VIDEO,
    CODEC_TYPE_AUDIO,
};

enum PixelFormat {
    PIX_FMT_YUV420P,
    PIX_FMT_YUV422,
    PIX_FMT_RGB24,
};

/* motion estimation type */
extern int motion_estimation_method;
#define ME_ZERO   0
#define ME_FULL   1
#define ME_LOG    2
#define ME_PHODS  3

/* encoding support */

#define CODEC_FLAG_HQ     0x0001 /* high quality (non real time) encoding */
#define CODEC_FLAG_QSCALE 0x0002 /* use fixed qscale */

typedef struct AVEncodeContext {
    int bit_rate;
    int rate; /* frames per sec or samples per sec */
    int flags;

    /* video only */
    int width, height;
    int gop_size; /* 0 = intra only */
    int pix_fmt;  /* pixel format, see PIX_FMT_xxx */
    /* audio only */
    int channels;

    /* the following data should not be initialized */
    int frame_size; /* in samples, initialized when calling 'init' */
    int frame_number; /* audio or video frame number */
    int key_frame;    /* true if the previous compressed frame was 
                         a key frame (intra, or seekable) */
    int quality;      /* quality of the previous encoded frame 
                         (between 1 (good) and 31 (bad)) */
    struct AVEncoder *codec;
    struct AVDecoder *decoder;
    void *priv_data;
} AVEncodeContext;

typedef struct AVEncoder {
    char *name;
    int type;
    int id;
    int priv_data_size;
    int (*init)(AVEncodeContext *);
    int (*encode)(AVEncodeContext *, UINT8 *buf, int buf_size, void *data);
    int (*close)(AVEncodeContext *);
    int is_decoder; /* true if it is a decoder */
    struct AVEncoder *next;
} AVEncoder;

extern AVEncoder ac3_encoder;
extern AVEncoder mp2_encoder;
extern AVEncoder mpeg1video_encoder;
extern AVEncoder h263_encoder;
extern AVEncoder rv10_encoder;
extern AVEncoder mjpeg_encoder;
extern AVEncoder divx_encoder;
extern AVEncoder msmpeg4_encoder;

/* pcm.c */
extern AVEncoder pcm_encoder;
extern AVEncoder pcm_decoder;
extern AVEncoder rawvideo_encoder;
extern AVEncoder rawvideo_decoder;


/* dummy decoders, just to be able to read avi */
extern AVEncoder msmpeg4_decoder;
extern AVEncoder mp3_decoder;

/* resample.c */

struct ReSampleContext;

typedef struct ReSampleContext ReSampleContext;

ReSampleContext *audio_resample_init(int output_channels, int input_channels, 
                                     int output_rate, int input_rate);
int audio_resample(ReSampleContext *s, short *output, short *input, int nb_samples);
void audio_resample_close(ReSampleContext *s);

/* YUV420 format is assumed ! */

struct ImgReSampleContext;

typedef struct ImgReSampleContext ImgReSampleContext;

ImgReSampleContext *img_resample_init(int output_width, int output_height,
                                      int input_width, int input_height);
void img_resample(ImgReSampleContext *s, 
                  UINT8 *output, int owrap, 
                  UINT8 *input, int iwrap);

void img_resample_close(ImgReSampleContext *s);

int img_convert_to_yuv420(UINT8 *img_out, UINT8 *img, 
                          int pix_fmt, int width, int height);

/* fixed qscale, for testing */
