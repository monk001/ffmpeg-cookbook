/*
 * MSMPEG4 backend for ffmpeg encoder
 * Copyright (c) 2001 Gerard Lantau.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <stdlib.h>
#include <stdio.h>
#include <netinet/in.h>
#include "common.h"
#include "dsputil.h"
#include "mpegvideo.h"

/*
 * You can also call this codec : MPEG4 with a twist ! 
 *
 * TODO: 
 *        - select best mv table (two choices)
 *        - select best vlc table 
 *        - optimize size of VLC tables and vlc_index tables
 */
//#define DEBUG

/* run length table */
typedef struct RLTable {
    int is_intra; /* true if for intra blocks */
    int n; /* number of entries of table_vlc minus 1 */
    int last; /* number of values for last = 0 */
    const UINT16 (*table_vlc)[2];
    const INT8 *table_run;
    const INT8 *table_level;
    /* tables for encoding only */
    UINT16 *table_vlc_index[2];
} RLTable;

/* motion vector table */
typedef struct MVTable {
    int n;
    const UINT16 *table_mv_code;
    const UINT8 *table_mv_bits;
    const UINT8 *table_mvx;
    const UINT8 *table_mvy;
    UINT16 *table_mv_index; /* convert mv to index in table_mv */
} MVTable;

static void msmpeg4_encode_block(MpegEncContext * s, DCTELEM * block, int n);

#ifdef DEBUG
int mb_count;
int motion_count;
int frame_count = 0;
#endif
/* XXX: move it to mpegvideo.h */
static int mv_table_index;
static int rl_table_index;
static int rl_chroma_table_index;
static int dc_table_index;
static int use_skip_mb_code;

static int init_done = 0;

#include "msmpeg4data.h"

/* build the table which associate a (x,y) motion vector to a vlc */
static void init_mv_table(MVTable *tab)
{
    int i, x, y;

    tab->table_mv_index = malloc(sizeof(UINT16) * 4096);
    /* mark all entries as not used */
    for(i=0;i<4096;i++)
        tab->table_mv_index[i] = tab->n;
    
    for(i=0;i<tab->n;i++) {
        x = tab->table_mvx[i];
        y = tab->table_mvy[i];
        tab->table_mv_index[(x << 6) | y] = i;
    }
}

#define RUN_BITS 6
#define LEVEL_BITS 6
#define RUN_MAX    (1 << RUN_BITS)  
#define LEVEL_MAX  (1 << LEVEL_BITS)  

//#define RL_DEBUG

/* build the table which associate an (run, level, last) to a vlc 
 */
static void init_rl_table(RLTable *tab)
{
    int last, run, level, start, len, i, j, v;
    int size, index;
    UINT16 *table_vlci;
    UINT8 level_max[RUN_MAX+1];
    UINT8 run_max[LEVEL_MAX+1];

    /* three tables are generated */
    for(last=0;last<2;last++) {
        if (last == 0) {
            start = 0;
            len = tab->last;
        } else {
            start = tab->last;
            len = tab->n - start;
        }
        size = (1 << (RUN_BITS + LEVEL_BITS));
        table_vlci = malloc(sizeof(UINT16) * size);
        for(i=0;i<size;i++) 
            table_vlci[i] = 3 << 14;
            
        memset(level_max, 0, sizeof(level_max));
        memset(run_max, 0, sizeof(run_max));

        /* compute the add tables */
        for(i=start;i<start+len;i++) {
            run = tab->table_run[i];
            level = tab->table_level[i];
            if (level > level_max[run])
                level_max[run] = level;
            if (run > run_max[level])
                run_max[level] = run;
        }

        for(j=0;j<3;j++) {
            for(i=start;i<start+len;i++) {
                run = tab->table_run[i];
                level = tab->table_level[i];
                if (j == 1) {
                    v = level_max[run];
                    level += v;
                } else if (j == 2) {
                    v = run_max[level];
                    /* XXX: the following is clearly a bug they made
                       in their VLC table. to be compatible we must do
                       it too ! */
                    if (tab->is_intra) {
                        if (v == 0)
                            continue;
                        run += v;
                    } else {
                        run += v + 1;
                    }
                    /* no need to add invalid runs */
                    if (run >= 64)
                        continue;
                }
#ifdef RL_DEBUG
                printf("run=%d level=%d\n", run, level);
#endif
                if (run >= RUN_MAX ||
                    level >= LEVEL_MAX)
                    abort();
                index = (run << LEVEL_BITS) | level;
                if (table_vlci[index] == (3 << 14)) {
                    table_vlci[index] = i | (j << 14);
                }
            }
        }
#ifdef RL_DEBUG
        printf("last=%d: run_max = %d level_max = %d\n", 
               last, run_max, level_max);
#endif
        tab->table_vlc_index[last] = table_vlci;
    }
}

static void code012(PutBitContext *pb, int n)
{
    if (n == 0) {
        put_bits(pb, 1, 0);
    } else {
        put_bits(pb, 1, 1);
        put_bits(pb, 1, (n >= 2));
    }
}

/* write MSMPEG4 V3 compatible frame header */
void msmpeg4_encode_picture_header(MpegEncContext * s, int picture_number)
{
    int i;

    align_put_bits(&s->pb);

    put_bits(&s->pb, 2, s->pict_type - 1);

    put_bits(&s->pb, 5, s->qscale);

    rl_table_index = 2;
    rl_chroma_table_index = 1; /* only for I frame */
    dc_table_index = 1;
    mv_table_index = 1; /* only if P frame */
    use_skip_mb_code = 1; /* only if P frame */
    
    if (s->pict_type == I_TYPE) {
        put_bits(&s->pb, 5, 0x17); /* XXX: unknown use */

        code012(&s->pb, rl_chroma_table_index);
        code012(&s->pb, rl_table_index);

        put_bits(&s->pb, 1, dc_table_index);
    } else {
        put_bits(&s->pb, 1, use_skip_mb_code);
        
        rl_chroma_table_index = rl_table_index;
        code012(&s->pb, rl_table_index);

        put_bits(&s->pb, 1, dc_table_index);

        put_bits(&s->pb, 1, mv_table_index);
    }

    if (!init_done) {
        /* init various encoding tables */
        init_done = 1;
        init_mv_table(&mv_tables[0]);
        init_mv_table(&mv_tables[1]);
        for(i=0;i<NB_RL_TABLES;i++)
            init_rl_table(&rl_table[i]);
    }

#ifdef DEBUG
    mb_count = 0;
    motion_count = 0;
    printf("*****frame %d:\n", frame_count++);
#endif
}

/* predict coded block */
static inline int coded_block_pred(MpegEncContext * s, int n, int val)
{
    int x, y, wrap, pred, a, b, c;

    x = 2 * s->mb_x + 1 + (n & 1);
    y = 2 * s->mb_y + 1 + ((n & 2) >> 1);
    wrap = s->mb_width * 2 + 2;

    /* B C
     * A X 
     */
    a = s->coded_block[(x - 1) + (y) * wrap];
    b = s->coded_block[(x - 1) + (y - 1) * wrap];
    c = s->coded_block[(x) + (y - 1) * wrap];
    
    if (b == c) {
        pred = a;
    } else {
        pred = c;
    }
    
    /* store value */
    s->coded_block[(x) + (y) * wrap] = val;

    /* return encoded value */
    return pred ^ val;
}

static void msmpeg4_encode_motion(MpegEncContext * s, 
                                  int mx, int my)
{
    int code;
    MVTable *mv;

    /* modulo encoding */
    /* WARNING : you cannot reach all the MVs even with the modulo
       encoding. This is a somewhat strange compromise they took !!!  */
    mx += 32;
    if (mx < 0)
        mx += 64;
    else if (mx >= 64)
        mx -= 64;
    my += 32;
    if (my < 0)
        my += 64;
    else if (my >= 64)
        my -= 64;
    
    mv = &mv_tables[mv_table_index];

    code = mv->table_mv_index[(mx << 6) | my];
    put_bits(&s->pb, 
             mv->table_mv_bits[code], 
             mv->table_mv_code[code]);
    if (code == mv->n) {
        /* escape : code litterally */
        put_bits(&s->pb, 6, mx);
        put_bits(&s->pb, 6, my);
    }
}

void msmpeg4_encode_mb(MpegEncContext * s, 
                       DCTELEM block[6][64],
                       int motion_x, int motion_y)
{
    int cbp, coded_cbp, i;
    int pred_x, pred_y;

    if (!s->mb_intra) {
	/* compute cbp */
	cbp = 0;
	for (i = 0; i < 6; i++) {
	    if (s->block_last_index[i] >= 0)
		cbp |= 1 << (5 - i);
	}
	if (use_skip_mb_code && (cbp | motion_x | motion_y) == 0) {
	    /* skip macroblock */
	    put_bits(&s->pb, 1, 1);
	    return;
	}
        if (use_skip_mb_code)
            put_bits(&s->pb, 1, 0);	/* mb coded */
        
        put_bits(&s->pb, 
                 table_mb_non_intra[cbp + 64][1], 
                 table_mb_non_intra[cbp + 64][0]);

        /* motion vector */
        h263_pred_motion(s, 0, &pred_x, &pred_y);
        msmpeg4_encode_motion(s, motion_x - pred_x, 
                              motion_y - pred_y);
    } else {
	/* compute cbp */
	cbp = 0;
        coded_cbp = 0;
	for (i = 0; i < 6; i++) {
            int val;
            val = (s->block_last_index[i] >= 1);
            cbp |= val << (5 - i);
            if (i < 4) {
                /* predict value for close blocks only for luma */
                val = coded_block_pred(s, i, val);
            }
            coded_cbp |= val << (5 - i);
	}
#if 0
        if (coded_cbp)
            printf("cbp=%x %x\n", cbp, coded_cbp);
#endif

	if (s->pict_type == I_TYPE) {
            put_bits(&s->pb, 
                     table_mb_intra[coded_cbp][1], table_mb_intra[coded_cbp][0]);
        } else {
            if (use_skip_mb_code)
                put_bits(&s->pb, 1, 0);	/* mb coded */
            put_bits(&s->pb, 
                     table_mb_non_intra[cbp][1], 
                     table_mb_non_intra[cbp][0]);
        }
        put_bits(&s->pb, 1, 0);	/* ??? */
    }

    for (i = 0; i < 6; i++) {
        msmpeg4_encode_block(s, block[i], i);
    }
}


/* strongly inspirated from MPEG4, but not exactly the same ! */
void msmpeg4_dc_scale(MpegEncContext * s)
{
    int scale;

    if (s->qscale < 5)
        scale = 8;
    else if (s->qscale < 9)
        scale = 2 * s->qscale;
    else 
        scale = s->qscale + 8;
    s->y_dc_scale = scale;
    s->c_dc_scale = (s->qscale + 13) / 2;
}

#define DC_MAX 119

static void msmpeg4_encode_dc(MpegEncContext * s, int level1, int n)
{
    int sign, level, code;
    int a, b, c, x, y, wrap, pred, scale;
    UINT16 *dc_val;

    level = level1;
    /* find prediction */
    if (n < 4) {
	x = 2 * s->mb_x + 1 + (n & 1);
	y = 2 * s->mb_y + 1 + ((n & 2) >> 1);
	wrap = s->mb_width * 2 + 2;
	dc_val = s->dc_val[0];
	scale = s->y_dc_scale;
    } else {
	x = s->mb_x + 1;
	y = s->mb_y + 1;
	wrap = s->mb_width + 2;
	dc_val = s->dc_val[n - 4 + 1];
	scale = s->c_dc_scale;
    }

    /* B C
     * A X 
     */
    a = dc_val[(x - 1) + (y) * wrap];
    b = dc_val[(x - 1) + (y - 1) * wrap];
    c = dc_val[(x) + (y - 1) * wrap];

    /* XXX: the following solution consumes divisions, but it does not
       necessitate to modify mpegvideo.c. The problem comes from the
       fact they decided to store the quantized DC (which would lead
       to problems if Q could vary !) */
    a = (a + (scale >> 1)) / scale;
    b = (b + (scale >> 1)) / scale;
    c = (c + (scale >> 1)) / scale;

    /* XXX: WARNING: they did not choose the same test as MPEG4. This
       is very important ! */
    if (abs(a - b) <= abs(b - c)) {
	pred = c;
    } else {
	pred = a;
    }

    /* update predictor */
    dc_val[(x) + (y) * wrap] = level * scale;

    /* do the prediction */
    level -= pred;

    sign = 0;
    if (level < 0) {
        level = -level;
        sign = 1;
    }
    
    code = level;
    if (code > DC_MAX) 
        code = DC_MAX;

    if (dc_table_index == 0) {
        if (n < 4) {
            put_bits(&s->pb, table0_dc_lum[code][1], table0_dc_lum[code][0]);
        } else {
            put_bits(&s->pb, table0_dc_chroma[code][1], table0_dc_chroma[code][0]);
        }
    } else {
        if (n < 4) {
            put_bits(&s->pb, table1_dc_lum[code][1], table1_dc_lum[code][0]);
        } else {
            put_bits(&s->pb, table1_dc_chroma[code][1], table1_dc_chroma[code][0]);
        }
    }
        
    if (code == DC_MAX)
        put_bits(&s->pb, 8, level);
        
    if (level != 0) {
        put_bits(&s->pb, 1, sign);
    }
}

/* Encoding of a block. Very similar to MPEG4 except for a different
   escape coding (same as H263) and more vlc tables.
 */
static void msmpeg4_encode_block(MpegEncContext * s, DCTELEM * block, int n)
{
    int level, run, last, i, j, last_index, esc_level;
    int last_non_zero, sign, slevel;
    int code;
    const RLTable *rl;

    if (s->mb_intra) {
        msmpeg4_encode_dc(s, block[0], n);
        i = 1;
        if (n < 4) {
            rl = &rl_table[rl_table_index];
        } else {
            rl = &rl_table[3 + rl_chroma_table_index];
        }
    } else {
        i = 0;
        rl = &rl_table[6 + rl_table_index];
    }

    /* AC coefs */
    last_index = s->block_last_index[n];
    last_non_zero = i - 1;
    for (; i <= last_index; i++) {
	j = zigzag_direct[i];
	level = block[j];
	if (level) {
	    run = i - last_non_zero - 1;
	    last = (i == last_index);
	    sign = 0;
	    slevel = level;
	    if (level < 0) {
		sign = 1;
		level = -level;
	    }
            if (run >= RUN_MAX || level >= LEVEL_MAX) 
                goto esc3;
            code = rl->table_vlc_index[last][(run << LEVEL_BITS) | level];
            esc_level = code >> 14;
            code = code & 0x3fff;
            switch(esc_level) {
            case 0:
                put_bits(&s->pb, rl->table_vlc[code][1], rl->table_vlc[code][0]);
                put_bits(&s->pb, 1, sign);
                break;
            case 1:
                put_bits(&s->pb, rl->table_vlc[rl->n][1], rl->table_vlc[rl->n][0]);
                put_bits(&s->pb, 1, 1);
                put_bits(&s->pb, rl->table_vlc[code][1], rl->table_vlc[code][0]);
                put_bits(&s->pb, 1, sign);
                break;
            case 2:
                put_bits(&s->pb, rl->table_vlc[rl->n][1], rl->table_vlc[rl->n][0]);
                put_bits(&s->pb, 1, 0);
                put_bits(&s->pb, 1, 1);
                put_bits(&s->pb, rl->table_vlc[code][1], rl->table_vlc[code][0]);
                put_bits(&s->pb, 1, sign);
                break;
            default:
            case 3:
            esc3:
                put_bits(&s->pb, rl->table_vlc[rl->n][1], rl->table_vlc[rl->n][0]);
                put_bits(&s->pb, 1, 0);
                put_bits(&s->pb, 1, 0);
                put_bits(&s->pb, 1, last);
                put_bits(&s->pb, 6, run);
                put_bits(&s->pb, 8, slevel & 0xff);
                break;
            }
	    last_non_zero = i;
	}
    }
}
