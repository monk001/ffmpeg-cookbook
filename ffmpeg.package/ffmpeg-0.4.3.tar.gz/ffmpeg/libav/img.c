/*
 * Image format
 * Copyright (c) 2000,2001 Gerard Lantau.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <math.h>

#include "avformat.h"

#define INFMT_YUV 1
#define INFMT_PGM 2
#define INFMT_PGMPIPE 3

typedef struct {
    int width;
    int height;
    int img_number;
    int img_size;
    int img_fmt;
    char path[1024];
} VideoData;

static inline int pnm_space(int c)  
{
    return (c==' ' || c=='\n' || c=='\r' || c=='\t');
}

static void pnm_get(ByteIOContext *f, char *str, int buf_size) 
{
    char *s;
    int c;
    
    do  {
        c=get_byte(f);
        if (c=='#')  {
            do  {
                c=get_byte(f);
            } while (c!='\n');
            c=get_byte(f);
        }
    } while (pnm_space(c));
    
    s=str;
    do  {
        if (url_feof(f))
            break;
        if ((s - str)  < buf_size - 1)
            *s++=c;
        c=get_byte(f);
    } while (!pnm_space(c));
    *s = '\0';
}

static int pgm_read(VideoData *s, const char *filename, UINT8 *buf, int size)
{
    int width, height, i;
    ByteIOContext pb1, *f = &pb1;
    char buf1[32];
    UINT8 *picture[3];

    width = s->width;
    height = s->height;
    if (url_fopen(f, filename, URL_RDONLY) < 0)
        return -EIO;

    pnm_get(f, buf1, sizeof(buf1));
    if (strcmp(buf1, "P5")) {
        url_fclose(f);
        return -EIO;
    }
    pnm_get(f, buf1, sizeof(buf1));
    pnm_get(f, buf1, sizeof(buf1));
    pnm_get(f, buf1, sizeof(buf1));
    
    picture[0] = buf;
    picture[1] = buf + width * height;
    picture[2] = buf + width * height + (width * height / 4);
    
    get_buffer(f, picture[0], width * height);
    for(i=0;i<height/2;i++) {
        get_buffer(f, picture[1] + i * width/2, width/2);
        get_buffer(f, picture[2] + i * width/2, width/2);
    }
    url_fclose(f);
    return 0;
}

static int yuv_read(VideoData *s, const char *filename, UINT8 *buf, int size1)
{
    ByteIOContext pb1, *pb = &pb1;
    char fname[1024], *p;
    int size;

    size = s->width * s->height;
    
    strcpy(fname, filename);
    p = strrchr(fname, '.');
    if (!p || p[1] != 'Y')
        return -EIO;

    if (url_fopen(pb, fname, URL_RDONLY) < 0)
        return -EIO;
    
    get_buffer(pb, buf, size);
    url_fclose(pb);
    
    p[1] = 'U';
    if (url_fopen(pb, fname, URL_RDONLY) < 0)
        return -EIO;

    get_buffer(pb, buf + size, size / 4);
    url_fclose(pb);
    
    p[1] = 'V';
    if (url_fopen(pb, fname, URL_RDONLY) < 0)
        return -EIO;

    get_buffer(pb, buf + size + (size / 4), size / 4);
    url_fclose(pb);
    return 0;
}

int img_read_packet(AVFormatContext *s1, AVPacket *pkt)
{
    VideoData *s = s1->priv_data;
    char filename[1024];
    int ret;

    snprintf(filename, sizeof(filename), s->path, s->img_number);
    av_new_packet(pkt, s->img_size);
    pkt->stream_index = 0;
    
    switch(s->img_fmt) {
    case INFMT_PGM:
        ret = pgm_read(s, filename, pkt->data, pkt->size);
        break;
    case INFMT_YUV:
        ret = yuv_read(s, filename, pkt->data, pkt->size);
        break;
    default:
        return -EIO;
    }
    if (ret < 0) {
        av_free_packet(pkt);
        return -EIO; /* signal EOF */
    } else {
        s->img_number++;
        return 0;
    }
}

static int sizes[][2] = {
    { 640, 480 },
    { 720, 480 },
    { 720, 576 },
    { 352, 288 },
    { 352, 240 },
    { 160, 128 },
    { 512, 384 },
};

static int infer_size(int *width_ptr, int *height_ptr, int size)
{
    int i;

    for(i=0;i<sizeof(sizes)/sizeof(sizes[0]);i++) {
        if ((sizes[i][0] * sizes[i][1]) == size) {
            *width_ptr = sizes[i][0];
            *height_ptr = sizes[i][1];
            return 0;
        }
    }
    return -1;
}

static int img_read_header(AVFormatContext *s1, AVFormatParameters *ap)
{
    VideoData *s;
    int i;
    char buf[1024];
    char buf1[32];
    ByteIOContext pb1, *f = &pb1;
    AVStream *st;

    s = malloc(sizeof(VideoData));
    if (!s)
        return -ENOMEM;

    s1->priv_data = s;

    s1->nb_streams = 1;
    st = av_mallocz(sizeof(AVStream));
    if (!st) {
        free(s);
        return -ENOMEM;
    }
    s1->streams[0] = st;
    
    strcpy(s->path, s1->filename);
    s->img_number = 0;

    /* find format */
    if (match_ext(s->path, "pgm"))
        s->img_fmt = INFMT_PGM;
    else if (match_ext(s->path, "Y"))
        s->img_fmt = INFMT_YUV;
    else
        goto fail;

    /* try to find the first image */
    for(i=0;i<5;i++) {
        snprintf(buf, sizeof(buf), s->path, s->img_number);
        if (url_fopen(f, buf, URL_RDONLY) >= 0)
            break;
        s->img_number++;
    }
    if (i == 5)
        goto fail;
    
    /* find the image size */
    switch(s->img_fmt) {
    case INFMT_PGM:
        pnm_get(f, buf1, sizeof(buf1));
        pnm_get(f, buf1, sizeof(buf1));
        s->width = atoi(buf1);
        pnm_get(f, buf1, sizeof(buf1));
        s->height = (atoi(buf1) * 2) / 3;
        if (s->width <= 0 ||
            s->height <= 0) {
            url_fclose(f);
            goto fail;
        }
        break;
    case INFMT_YUV:
        /* infer size by using the file size. We choose the size
           closest to the 4/3 ratio */
        {
            int img_size;
            URLContext *h;

            /* XXX: hack hack */
            h = url_fileno(f);
            img_size = lseek((int)h->priv_data, 0, SEEK_END);
            if (infer_size(&s->width, &s->height, img_size) < 0) {
                url_fclose(f);
                goto fail;
            }
        }
        break;
    }

    url_fclose(f);
    
    s->img_size = (s->width * s->height * 3) / 2;

    st->codec.codec = avcodec_find_decoder(CODEC_ID_RAWVIDEO);

    st->codec.width = s->width;
    st->codec.height = s->height;
    st->codec.pix_fmt = PIX_FMT_YUV420P;
    if (!ap || !ap->frame_rate)
        st->codec.rate = 25;
    else
        st->codec.rate = ap->frame_rate;
    
    return 0;
 fail:
    free(s);
    return -EIO;
}

static int img_read_close(AVFormatContext *s1)
{
    VideoData *s = s1->priv_data;
    free(s);
    return 0;
}

/******************************************************/
/* image output */

int pgm_save(AVPicture *picture, int width, int height, ByteIOContext *pb) 
{
    int i;
    char buf[100];
    UINT8 *ptr, *ptr1, *ptr2;

    snprintf(buf, sizeof(buf), 
             "P5\n%d %d\n%d\n",
             width, (height * 3) / 2, 255);
    put_buffer(pb, buf, strlen(buf));
    
    ptr = picture->data[0];
    for(i=0;i<height;i++) {
        put_buffer(pb, ptr, width);
        ptr += picture->linesize[0];
    }

    height >>= 1;
    width >>= 1;
    ptr1 = picture->data[1];
    ptr2 = picture->data[2];
    for(i=0;i<height;i++) {
        put_buffer(pb, ptr1, width);
        put_buffer(pb, ptr2, width);
        ptr1 += picture->linesize[1];
        ptr2 += picture->linesize[2];
    }
    put_flush_packet(pb);
    return 0;
}

static int yuv_save(AVPicture *picture, int width, int height, const char *filename)
{
    ByteIOContext pb1, *pb = &pb1;
    char fname[1024], *p;
    int i, j;
    UINT8 *ptr;
    static char *ext = "YUV";

    strcpy(fname, filename);
    p = strrchr(fname, '.');
    if (!p || p[1] != 'Y')
        return -EIO;

    for(i=0;i<3;i++) {
        if (i == 1) {
            width >>= 1;
            height >>= 1;
        }

        p[1] = ext[i];
        if (url_fopen(pb, fname, URL_WRONLY) < 0)
            return -EIO;
    
        ptr = picture->data[i];
        for(j=0;j<height;j++) {
            put_buffer(pb, ptr, width);
            ptr += picture->linesize[i];
        }
        put_flush_packet(pb);
        url_fclose(pb);
    }
    return 0;
}

static int img_write_header(AVFormatContext *s)
{
    VideoData *img;

    img = av_mallocz(sizeof(VideoData));
    if (!img)
        return -1;
    s->priv_data = img;
    img->img_number = 1;
    strcpy(img->path, s->filename);
    /* find format */
    if (s->format == &pgmpipe_format)
        img->img_fmt = INFMT_PGMPIPE;
    else if (match_ext(img->path, "pgm"))
        img->img_fmt = INFMT_PGM;
    else if (match_ext(img->path, "Y"))
        img->img_fmt = INFMT_YUV;
    else
        goto fail;
    return 0;
 fail:
    free(img);
    return -EIO;
}

static int img_write_packet(AVFormatContext *s, int stream_index,
                            UINT8 *buf, int size)
{
    VideoData *img = s->priv_data;
    AVStream *st = s->streams[stream_index];
    ByteIOContext pb1, *pb = &pb1;
    AVPicture picture;
    int width, height, ret, size1;
    char filename[1024];

    width = st->codec.width;
    height = st->codec.height;
    size1 = (width * height * 3) / 2;
    if (size != size1)
        return -EIO;

    picture.data[0] = buf;
    picture.data[1] = picture.data[0] + width * height;
    picture.data[2] = picture.data[1] + (width * height) / 4;
    picture.linesize[0] = width;
    picture.linesize[1] = width >> 1; 
    picture.linesize[2] = width >> 1;
    snprintf(filename, sizeof(filename), img->path, img->img_number);
    switch(img->img_fmt) {
    case INFMT_PGM:
        if (url_fopen(pb, filename, URL_WRONLY) < 0)
            return -EIO;
        ret = pgm_save(&picture, width, height, pb);
        url_fclose(pb);
        break;
    case INFMT_YUV:
        ret = yuv_save(&picture, width, height, filename);
        break;
    case INFMT_PGMPIPE:
        ret = pgm_save(&picture, width, height, &s->pb);
        break;
    }
    img->img_number++;
    return 0;
}

static int img_write_trailer(AVFormatContext *s)
{
    VideoData *img = s->priv_data;
    free(img);
    return 0;
}

AVFormat img_format = {
    "img",
    "image format",
    "",
    "pgm,Y",
    CODEC_ID_NONE,
    CODEC_ID_RAWVIDEO,
    img_write_header,
    img_write_packet,
    img_write_trailer,

    img_read_header,
    img_read_packet,
    img_read_close,
    NULL,
    AVFMT_NOFILE,
};

/****************************************************/
/* PGM pipe format */

static int pgmpipe_read_header(AVFormatContext *s, AVFormatParameters *ap)
{
    AVStream *st;
    ByteIOContext *f = &s->pb;
    char buf1[32];
    int width, height;

    s->nb_streams = 1;
    st = av_mallocz(sizeof(AVStream));
    if (!st) {
        free(s);
        return -ENOMEM;
    }
    s->streams[0] = st;

    pnm_get(f, buf1, sizeof(buf1));
    if (strcmp(buf1, "P5")) {
        return -EIO;
    }
    pnm_get(f, buf1, sizeof(buf1));
    width = atoi(buf1);
    pnm_get(f, buf1, sizeof(buf1));
    height = atoi(buf1);
    pnm_get(f, buf1, sizeof(buf1));

    height = (height * 2) / 3;

    if (width <= 0 ||
        height <= 0 ||
        (width % 2) != 0 ||
        (height % 2) != 0)
        return -1;
    
    /* seek again to zero */
    url_fseek(f, 0, SEEK_SET);

    st->codec.codec = avcodec_find_decoder(CODEC_ID_RAWVIDEO);

    st->codec.width = width;
    st->codec.height = height;
    st->codec.pix_fmt = PIX_FMT_YUV420P;
    if (!ap || !ap->frame_rate)
        st->codec.rate = 25;
    else
        st->codec.rate = ap->frame_rate;

    return 0;
}

int pgmpipe_read_packet(AVFormatContext *s, AVPacket *pkt)
{
    int width, height, size, i;
    ByteIOContext *f = &s->pb;
    UINT8 *picture[3];
    char buf1[32];

    if (url_feof(f))
        return -EIO;

    pnm_get(f, buf1, sizeof(buf1));
    if (strcmp(buf1, "P5")) {
        return -EIO;
    }
    pnm_get(f, buf1, sizeof(buf1));
    width = atoi(buf1);
    pnm_get(f, buf1, sizeof(buf1));
    height = atoi(buf1);
    pnm_get(f, buf1, sizeof(buf1));

    height = (height * 2) / 3;

    if (width <= 0 ||
        height <= 0 ||
        (width % 2) != 0 ||
        (height % 2) != 0)
        return -1;
    
    size = (width * height * 3) / 2;
    
    av_new_packet(pkt, size);
    pkt->stream_index = 0;
    
    picture[0] = pkt->data;
    picture[1] = picture[0] + width * height;
    picture[2] = picture[1] + (width * height / 4);
    
    get_buffer(f, picture[0], width * height);
    height >>= 1;
    width >>= 1;
    for(i=0;i<height;i++) {
        get_buffer(f, picture[1] + i * width, width);
        get_buffer(f, picture[2] + i * width, width);
    }
    return 0;
}

static int pgmpipe_read_close(AVFormatContext *s1)
{
    return 0;
}

AVFormat pgmpipe_format = {
    "pgmpipe",
    "PGM pipe format",
    "",
    "pgm",
    CODEC_ID_NONE,
    CODEC_ID_RAWVIDEO,
    img_write_header,
    img_write_packet,
    img_write_trailer,

    pgmpipe_read_header,
    pgmpipe_read_packet,
    pgmpipe_read_close,
    NULL,
};
