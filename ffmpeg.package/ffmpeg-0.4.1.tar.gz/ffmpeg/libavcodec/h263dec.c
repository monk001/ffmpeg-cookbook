/*
 * H263 decoder
 * Copyright (c) 2001 Gerard Lantau.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <netinet/in.h>
#include "avcodec.h"

static int decode_init(AVEncodeContext *s)
{
    return 0;
}

static int decode_frame(AVEncodeContext *s, UINT8 *buf, int buf_size, void *data)
{
    memcpy(data, buf, buf_size);
    return buf_size;
}

AVEncoder msmpeg4_decoder = {
    "msmpeg4",
    CODEC_TYPE_VIDEO,
    CODEC_ID_MSMPEG4,
    0,
    decode_init,
    decode_frame,
    NULL,
    1, /* is_decoder */
};

AVEncoder mp3_decoder = {
    "mp3",
    CODEC_TYPE_AUDIO,
    CODEC_ID_MP2,
    0,
    decode_init,
    decode_frame,
    NULL,
    1, /* is_decoder */
};
