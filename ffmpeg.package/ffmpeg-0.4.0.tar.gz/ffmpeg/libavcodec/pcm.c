/*
 * PCM codec
 * Copyright (c) 2001 Gerard Lantau.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <netinet/in.h>
#include "avcodec.h"

#define PCM_FRAME_SIZE 256

static int encode_init(AVEncodeContext *avctx)
{
    avctx->bit_rate = avctx->rate * avctx->channels * 16;
    avctx->frame_size = PCM_FRAME_SIZE;
    avctx->key_frame = 1; /* always key frame */
    return 0;
}

/* signed 16 bits, little endian */
/* XXX: sort out frame size pb */
static int encode_frame(AVEncodeContext *avctx,
                        unsigned char *frame, int buf_size, void *data)
{
    short *p, *samples = data;
    int i, j, v, nb_channels;
    UINT8 *q;

    nb_channels = avctx->channels;
    q = frame;
    p = samples;
    for(i=0;i<PCM_FRAME_SIZE;i++) {
        for(j=0;j<nb_channels;j++) {
            v = p[j];
            q[0] = v;
            q[1] = v >> 8;
            q += 2;
        }
        p += nb_channels;
    }

    return PCM_FRAME_SIZE * nb_channels * 2;
}

static int decode_init(AVEncodeContext *s)
{
    return 0;
}

static int decode_frame(AVEncodeContext *s, UINT8 *buf, int buf_size, void *data)
{
    memcpy(data, buf, buf_size);
    return buf_size;
}

/* dummy pcm codec */
AVEncoder pcm_encoder = {
    "pcm",
    CODEC_TYPE_AUDIO,
    CODEC_ID_PCM,
    0,
    encode_init,
    encode_frame,
    NULL,
};

AVEncoder pcm_decoder = {
    "pcm",
    CODEC_TYPE_AUDIO,
    CODEC_ID_PCM,
    0,
    decode_init,
    decode_frame,
    NULL,
    1, /* is_decoder */
};
