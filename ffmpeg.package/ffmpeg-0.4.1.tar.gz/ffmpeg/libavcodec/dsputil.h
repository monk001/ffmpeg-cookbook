#ifndef DSPUTIL_H
#define DSPUTIL_H

#include "common.h"
#include <stdint.h>

/* dct code */
typedef short DCTELEM;

void jpeg_fdct_ifast (DCTELEM *data);

void j_rev_dct (DCTELEM *data);

void fdct_mmx(DCTELEM *block);

/* pixel operations */
#define MAX_NEG_CROP 384

/* temporary */
extern UINT32 squareTbl[512];

/* add and sub pixel */
extern void (*add_pixels_tab[4])(DCTELEM *block, const UINT8 *pixels, int line_size);
extern void (*sub_pixels_tab[4])(DCTELEM *block, const UINT8 *pixels, int line_size);

void dsputil_init(void);
void get_pixels(DCTELEM *block, const UINT8 *pixels, int line_size);
void put_pixels(const DCTELEM *block, UINT8 *pixels, int line_size);

#define add_pixels_2(block, pixels, line_size, dxy) \
   add_pixels_tab[dxy](block, pixels, line_size)

#define sub_pixels_2(block, pixels, line_size, dxy) \
   sub_pixels_tab[dxy](block, pixels, line_size)

extern void (*add_pixels_tab[4])(DCTELEM *block, const UINT8 *pixels, int line_size);

/* motion estimation */
int pix_abs16x16(unsigned char *blk1, unsigned char *blk2, int lx, int h);
int pix_abs16x16_x2(unsigned char *blk1, unsigned char *blk2, int lx, int h);
int pix_abs16x16_y2(unsigned char *blk1, unsigned char *blk2, int lx, int h);
int pix_abs16x16_xy2(unsigned char *blk1, unsigned char *blk2, int lx, int h);

#ifdef CONFIG_MMX
int pix_abs16x16_mmx(unsigned char *blk1, unsigned char *blk2, int lx, int h);
int pix_abs16x16_sse(unsigned char *blk1, unsigned char *blk2, int lx, int h);
int pix_abs16x16_x2_mmx(unsigned char *blk1, unsigned char *blk2, int lx, int h);
int pix_abs16x16_y2_mmx(unsigned char *blk1, unsigned char *blk2, int lx, int h);
int pix_abs16x16_xy2_mmx(unsigned char *blk1, unsigned char *blk2, int lx, int h);

#ifdef CONFIG_SSE
#define pix_abs16x16 pix_abs16x16_sse
#else
#define pix_abs16x16 pix_abs16x16_mmx
#endif
#define pix_abs16x16_x2 pix_abs16x16_x2_mmx
#define pix_abs16x16_y2 pix_abs16x16_y2_mmx
#define pix_abs16x16_xy2 pix_abs16x16_xy2_mmx

static inline void emms(void)
{
	asm volatile ("emms;");
}

#endif

#endif
